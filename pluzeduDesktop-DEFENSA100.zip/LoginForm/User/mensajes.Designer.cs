﻿namespace LoginForm.User
{
    partial class mensajes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mensajes));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblEnviar = new System.Windows.Forms.Label();
            this.txtMensaje = new System.Windows.Forms.TextBox();
            this.lblIconEmojis = new System.Windows.Forms.Label();
            this.lblIconArchivos = new System.Windows.Forms.Label();
            this.flpConversaciones = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pnlMensajes = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblIconInfo = new System.Windows.Forms.Label();
            this.lblNombreConversacion = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblIconPlus = new System.Windows.Forms.Label();
            this.lblIconSearch = new System.Windows.Forms.Label();
            this.pnlInfo = new System.Windows.Forms.Panel();
            this.labelSecciones = new System.Windows.Forms.Label();
            this.lblNombreInfo = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.pnlBuscar = new System.Windows.Forms.Panel();
            this.lblBusqueda1 = new System.Windows.Forms.Label();
            this.flpBusqueda = new System.Windows.Forms.FlowLayoutPanel();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.btnIconRegresar = new System.Windows.Forms.Button();
            this.shapeContainer3 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.pnlAgregar = new System.Windows.Forms.Panel();
            this.pnlContinuar = new System.Windows.Forms.Panel();
            this.lblContinuar = new System.Windows.Forms.Label();
            this.flpAgregar = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlIntegrantes = new System.Windows.Forms.Panel();
            this.lblIntegrantes = new System.Windows.Forms.Label();
            this.pbxIntegrantes = new System.Windows.Forms.PictureBox();
            this.pnlNuevoGrupo = new System.Windows.Forms.Panel();
            this.lblNuevoGrupo = new System.Windows.Forms.Label();
            this.pbxNuevoGrupo = new System.Windows.Forms.PictureBox();
            this.lblBusqueda2 = new System.Windows.Forms.Label();
            this.txtAgregar = new System.Windows.Forms.TextBox();
            this.btnRetorno = new System.Windows.Forms.Button();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.flpConversaciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.pnlInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.pnlBuscar.SuspendLayout();
            this.pnlAgregar.SuspendLayout();
            this.pnlContinuar.SuspendLayout();
            this.pnlIntegrantes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxIntegrantes)).BeginInit();
            this.pnlNuevoGrupo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxNuevoGrupo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.panel1.Controls.Add(this.lblEnviar);
            this.panel1.Controls.Add(this.txtMensaje);
            this.panel1.Controls.Add(this.lblIconEmojis);
            this.panel1.Controls.Add(this.lblIconArchivos);
            this.panel1.Location = new System.Drawing.Point(280, 480);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(640, 40);
            this.panel1.TabIndex = 15;
            // 
            // lblEnviar
            // 
            this.lblEnviar.AutoSize = true;
            this.lblEnviar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblEnviar.Font = new System.Drawing.Font("Work Sans Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnviar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(152)))), ((int)(((byte)(213)))));
            this.lblEnviar.Location = new System.Drawing.Point(559, 11);
            this.lblEnviar.Name = "lblEnviar";
            this.lblEnviar.Size = new System.Drawing.Size(75, 19);
            this.lblEnviar.TabIndex = 20;
            this.lblEnviar.Text = "ENVIAR";
            this.lblEnviar.Click += new System.EventHandler(this.lblEnviar_Click);
            // 
            // txtMensaje
            // 
            this.txtMensaje.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.txtMensaje.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMensaje.Location = new System.Drawing.Point(101, 11);
            this.txtMensaje.Name = "txtMensaje";
            this.txtMensaje.Size = new System.Drawing.Size(451, 19);
            this.txtMensaje.TabIndex = 19;
            this.txtMensaje.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMensaje_KeyPress);
            // 
            // lblIconEmojis
            // 
            this.lblIconEmojis.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblIconEmojis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIconEmojis.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIconEmojis.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.lblIconEmojis.Location = new System.Drawing.Point(53, 0);
            this.lblIconEmojis.Margin = new System.Windows.Forms.Padding(0);
            this.lblIconEmojis.Name = "lblIconEmojis";
            this.lblIconEmojis.Size = new System.Drawing.Size(45, 40);
            this.lblIconEmojis.TabIndex = 18;
            this.lblIconEmojis.Text = "";
            this.lblIconEmojis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIconEmojis.Visible = false;
            // 
            // lblIconArchivos
            // 
            this.lblIconArchivos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblIconArchivos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIconArchivos.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIconArchivos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.lblIconArchivos.Location = new System.Drawing.Point(3, 0);
            this.lblIconArchivos.Margin = new System.Windows.Forms.Padding(0);
            this.lblIconArchivos.Name = "lblIconArchivos";
            this.lblIconArchivos.Size = new System.Drawing.Size(45, 40);
            this.lblIconArchivos.TabIndex = 17;
            this.lblIconArchivos.Text = "";
            this.lblIconArchivos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIconArchivos.Click += new System.EventHandler(this.lblIconArchivos_Click);
            // 
            // flpConversaciones
            // 
            this.flpConversaciones.AutoScroll = true;
            this.flpConversaciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.flpConversaciones.Controls.Add(this.pictureBox3);
            this.flpConversaciones.Location = new System.Drawing.Point(0, 40);
            this.flpConversaciones.Margin = new System.Windows.Forms.Padding(0);
            this.flpConversaciones.Name = "flpConversaciones";
            this.flpConversaciones.Size = new System.Drawing.Size(280, 480);
            this.flpConversaciones.TabIndex = 17;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox3.Enabled = false;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(3, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 18;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pnlMensajes
            // 
            this.pnlMensajes.AutoScroll = true;
            this.pnlMensajes.Location = new System.Drawing.Point(280, 40);
            this.pnlMensajes.Margin = new System.Windows.Forms.Padding(0);
            this.pnlMensajes.Name = "pnlMensajes";
            this.pnlMensajes.Size = new System.Drawing.Size(639, 440);
            this.pnlMensajes.TabIndex = 19;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(920, 40);
            this.panel2.TabIndex = 14;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.lblIconInfo);
            this.panel5.Controls.Add(this.lblNombreConversacion);
            this.panel5.Location = new System.Drawing.Point(280, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(640, 40);
            this.panel5.TabIndex = 18;
            // 
            // lblIconInfo
            // 
            this.lblIconInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblIconInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIconInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIconInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.lblIconInfo.Location = new System.Drawing.Point(588, 0);
            this.lblIconInfo.Margin = new System.Windows.Forms.Padding(0);
            this.lblIconInfo.Name = "lblIconInfo";
            this.lblIconInfo.Size = new System.Drawing.Size(45, 40);
            this.lblIconInfo.TabIndex = 2;
            this.lblIconInfo.Text = "";
            this.lblIconInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIconInfo.Click += new System.EventHandler(this.lblIconInfo_Click);
            // 
            // lblNombreConversacion
            // 
            this.lblNombreConversacion.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNombreConversacion.BackColor = System.Drawing.Color.Transparent;
            this.lblNombreConversacion.Font = new System.Drawing.Font("Work Sans", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreConversacion.Location = new System.Drawing.Point(3, 7);
            this.lblNombreConversacion.Name = "lblNombreConversacion";
            this.lblNombreConversacion.Size = new System.Drawing.Size(634, 25);
            this.lblNombreConversacion.TabIndex = 16;
            this.lblNombreConversacion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.lblIconPlus);
            this.panel4.Controls.Add(this.lblIconSearch);
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(280, 40);
            this.panel4.TabIndex = 17;
            // 
            // lblIconPlus
            // 
            this.lblIconPlus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblIconPlus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIconPlus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblIconPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIconPlus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.lblIconPlus.Location = new System.Drawing.Point(230, 0);
            this.lblIconPlus.Margin = new System.Windows.Forms.Padding(0);
            this.lblIconPlus.Name = "lblIconPlus";
            this.lblIconPlus.Size = new System.Drawing.Size(40, 40);
            this.lblIconPlus.TabIndex = 1;
            this.lblIconPlus.Text = "";
            this.lblIconPlus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIconPlus.Visible = false;
            this.lblIconPlus.Click += new System.EventHandler(this.lblIconPlus_Click);
            // 
            // lblIconSearch
            // 
            this.lblIconSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblIconSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIconSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIconSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.lblIconSearch.Location = new System.Drawing.Point(10, 0);
            this.lblIconSearch.Margin = new System.Windows.Forms.Padding(0);
            this.lblIconSearch.Name = "lblIconSearch";
            this.lblIconSearch.Size = new System.Drawing.Size(40, 40);
            this.lblIconSearch.TabIndex = 0;
            this.lblIconSearch.Text = "";
            this.lblIconSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIconSearch.Click += new System.EventHandler(this.lblIconSearch_Click);
            // 
            // pnlInfo
            // 
            this.pnlInfo.BackColor = System.Drawing.Color.White;
            this.pnlInfo.Controls.Add(this.labelSecciones);
            this.pnlInfo.Controls.Add(this.lblNombreInfo);
            this.pnlInfo.Controls.Add(this.pictureBox8);
            this.pnlInfo.Controls.Add(this.btnCerrar);
            this.pnlInfo.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlInfo.Location = new System.Drawing.Point(660, 0);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(260, 520);
            this.pnlInfo.TabIndex = 20;
            this.pnlInfo.Visible = false;
            // 
            // labelSecciones
            // 
            this.labelSecciones.AutoSize = true;
            this.labelSecciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelSecciones.Location = new System.Drawing.Point(4, 185);
            this.labelSecciones.Name = "labelSecciones";
            this.labelSecciones.Size = new System.Drawing.Size(102, 19);
            this.labelSecciones.TabIndex = 18;
            this.labelSecciones.Text = "Sección(es):";
            // 
            // lblNombreInfo
            // 
            this.lblNombreInfo.AllowDrop = true;
            this.lblNombreInfo.BackColor = System.Drawing.Color.Transparent;
            this.lblNombreInfo.Location = new System.Drawing.Point(1, 135);
            this.lblNombreInfo.Name = "lblNombreInfo";
            this.lblNombreInfo.Size = new System.Drawing.Size(259, 40);
            this.lblNombreInfo.TabIndex = 17;
            this.lblNombreInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(89, 40);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(85, 85);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 16;
            this.pictureBox8.TabStop = false;
            // 
            // btnCerrar
            // 
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrar.ForeColor = System.Drawing.Color.Red;
            this.btnCerrar.Location = new System.Drawing.Point(1, 1);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(47, 37);
            this.btnCerrar.TabIndex = 0;
            this.btnCerrar.Text = "";
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // pnlBuscar
            // 
            this.pnlBuscar.BackColor = System.Drawing.Color.White;
            this.pnlBuscar.Controls.Add(this.lblBusqueda1);
            this.pnlBuscar.Controls.Add(this.flpBusqueda);
            this.pnlBuscar.Controls.Add(this.txtBuscar);
            this.pnlBuscar.Controls.Add(this.btnIconRegresar);
            this.pnlBuscar.Controls.Add(this.shapeContainer3);
            this.pnlBuscar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlBuscar.Location = new System.Drawing.Point(0, 0);
            this.pnlBuscar.Name = "pnlBuscar";
            this.pnlBuscar.Size = new System.Drawing.Size(280, 520);
            this.pnlBuscar.TabIndex = 21;
            this.pnlBuscar.Visible = false;
            // 
            // lblBusqueda1
            // 
            this.lblBusqueda1.BackColor = System.Drawing.Color.Transparent;
            this.lblBusqueda1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblBusqueda1.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBusqueda1.ForeColor = System.Drawing.Color.Silver;
            this.lblBusqueda1.Location = new System.Drawing.Point(11, 11);
            this.lblBusqueda1.Name = "lblBusqueda1";
            this.lblBusqueda1.Size = new System.Drawing.Size(25, 25);
            this.lblBusqueda1.TabIndex = 24;
            this.lblBusqueda1.Text = "";
            // 
            // flpBusqueda
            // 
            this.flpBusqueda.AutoScroll = true;
            this.flpBusqueda.Location = new System.Drawing.Point(0, 43);
            this.flpBusqueda.Name = "flpBusqueda";
            this.flpBusqueda.Size = new System.Drawing.Size(280, 466);
            this.flpBusqueda.TabIndex = 20;
            // 
            // txtBuscar
            // 
            this.txtBuscar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBuscar.Font = new System.Drawing.Font("Work Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBuscar.Location = new System.Drawing.Point(45, 15);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.ShortcutsEnabled = false;
            this.txtBuscar.Size = new System.Drawing.Size(187, 19);
            this.txtBuscar.TabIndex = 1;
            this.txtBuscar.TextChanged += new System.EventHandler(this.txtBuscar_TextChanged);
            this.txtBuscar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBuscar_KeyPress);
            // 
            // btnIconRegresar
            // 
            this.btnIconRegresar.FlatAppearance.BorderSize = 0;
            this.btnIconRegresar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnIconRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIconRegresar.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIconRegresar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(152)))), ((int)(((byte)(213)))));
            this.btnIconRegresar.Location = new System.Drawing.Point(235, 4);
            this.btnIconRegresar.Name = "btnIconRegresar";
            this.btnIconRegresar.Size = new System.Drawing.Size(45, 37);
            this.btnIconRegresar.TabIndex = 0;
            this.btnIconRegresar.Text = "";
            this.btnIconRegresar.UseVisualStyleBackColor = true;
            this.btnIconRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // shapeContainer3
            // 
            this.shapeContainer3.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer3.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer3.Name = "shapeContainer3";
            this.shapeContainer3.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape2});
            this.shapeContainer3.Size = new System.Drawing.Size(280, 520);
            this.shapeContainer3.TabIndex = 23;
            this.shapeContainer3.TabStop = false;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.Color.LightGray;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 42;
            this.lineShape2.X2 = 231;
            this.lineShape2.Y1 = 36;
            this.lineShape2.Y2 = 36;
            // 
            // pnlAgregar
            // 
            this.pnlAgregar.BackColor = System.Drawing.Color.White;
            this.pnlAgregar.Controls.Add(this.pnlContinuar);
            this.pnlAgregar.Controls.Add(this.flpAgregar);
            this.pnlAgregar.Controls.Add(this.pnlIntegrantes);
            this.pnlAgregar.Controls.Add(this.pnlNuevoGrupo);
            this.pnlAgregar.Controls.Add(this.lblBusqueda2);
            this.pnlAgregar.Controls.Add(this.txtAgregar);
            this.pnlAgregar.Controls.Add(this.btnRetorno);
            this.pnlAgregar.Controls.Add(this.shapeContainer1);
            this.pnlAgregar.Location = new System.Drawing.Point(0, 0);
            this.pnlAgregar.Name = "pnlAgregar";
            this.pnlAgregar.Size = new System.Drawing.Size(280, 520);
            this.pnlAgregar.TabIndex = 22;
            this.pnlAgregar.Visible = false;
            // 
            // pnlContinuar
            // 
            this.pnlContinuar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnlContinuar.Controls.Add(this.lblContinuar);
            this.pnlContinuar.Location = new System.Drawing.Point(0, 462);
            this.pnlContinuar.Name = "pnlContinuar";
            this.pnlContinuar.Size = new System.Drawing.Size(280, 58);
            this.pnlContinuar.TabIndex = 28;
            this.pnlContinuar.Visible = false;
            // 
            // lblContinuar
            // 
            this.lblContinuar.BackColor = System.Drawing.Color.Transparent;
            this.lblContinuar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblContinuar.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContinuar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(152)))), ((int)(((byte)(213)))));
            this.lblContinuar.Location = new System.Drawing.Point(118, 12);
            this.lblContinuar.Name = "lblContinuar";
            this.lblContinuar.Size = new System.Drawing.Size(45, 34);
            this.lblContinuar.TabIndex = 18;
            this.lblContinuar.Text = "";
            // 
            // flpAgregar
            // 
            this.flpAgregar.AutoScroll = true;
            this.flpAgregar.AutoScrollMargin = new System.Drawing.Size(5, 5);
            this.flpAgregar.AutoSize = true;
            this.flpAgregar.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpAgregar.Location = new System.Drawing.Point(7, 108);
            this.flpAgregar.Name = "flpAgregar";
            this.flpAgregar.Size = new System.Drawing.Size(266, 400);
            this.flpAgregar.TabIndex = 20;
            this.flpAgregar.WrapContents = false;
            // 
            // pnlIntegrantes
            // 
            this.pnlIntegrantes.Controls.Add(this.lblIntegrantes);
            this.pnlIntegrantes.Controls.Add(this.pbxIntegrantes);
            this.pnlIntegrantes.Location = new System.Drawing.Point(7, 46);
            this.pnlIntegrantes.Name = "pnlIntegrantes";
            this.pnlIntegrantes.Size = new System.Drawing.Size(266, 56);
            this.pnlIntegrantes.TabIndex = 27;
            this.pnlIntegrantes.Visible = false;
            // 
            // lblIntegrantes
            // 
            this.lblIntegrantes.AutoSize = true;
            this.lblIntegrantes.BackColor = System.Drawing.Color.Transparent;
            this.lblIntegrantes.Location = new System.Drawing.Point(54, 17);
            this.lblIntegrantes.Name = "lblIntegrantes";
            this.lblIntegrantes.Size = new System.Drawing.Size(104, 19);
            this.lblIntegrantes.TabIndex = 18;
            this.lblIntegrantes.Text = "Integrantes:";
            // 
            // pbxIntegrantes
            // 
            this.pbxIntegrantes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pbxIntegrantes.Image = ((System.Drawing.Image)(resources.GetObject("pbxIntegrantes.Image")));
            this.pbxIntegrantes.Location = new System.Drawing.Point(8, 8);
            this.pbxIntegrantes.Name = "pbxIntegrantes";
            this.pbxIntegrantes.Size = new System.Drawing.Size(40, 40);
            this.pbxIntegrantes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxIntegrantes.TabIndex = 17;
            this.pbxIntegrantes.TabStop = false;
            // 
            // pnlNuevoGrupo
            // 
            this.pnlNuevoGrupo.Controls.Add(this.lblNuevoGrupo);
            this.pnlNuevoGrupo.Controls.Add(this.pbxNuevoGrupo);
            this.pnlNuevoGrupo.Location = new System.Drawing.Point(7, 46);
            this.pnlNuevoGrupo.Name = "pnlNuevoGrupo";
            this.pnlNuevoGrupo.Size = new System.Drawing.Size(266, 56);
            this.pnlNuevoGrupo.TabIndex = 26;
            this.pnlNuevoGrupo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlNuevoGrupo_MouseDown);
            this.pnlNuevoGrupo.MouseEnter += new System.EventHandler(this.pnlNuevoGrupo_MouseEnter);
            this.pnlNuevoGrupo.MouseLeave += new System.EventHandler(this.pnlNuevoGrupo_MouseLeave);
            this.pnlNuevoGrupo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlNuevoGrupo_MouseUp);
            // 
            // lblNuevoGrupo
            // 
            this.lblNuevoGrupo.AutoSize = true;
            this.lblNuevoGrupo.BackColor = System.Drawing.Color.Transparent;
            this.lblNuevoGrupo.Location = new System.Drawing.Point(89, 18);
            this.lblNuevoGrupo.Name = "lblNuevoGrupo";
            this.lblNuevoGrupo.Size = new System.Drawing.Size(112, 19);
            this.lblNuevoGrupo.TabIndex = 18;
            this.lblNuevoGrupo.Text = "Nuevo Grupo";
            this.lblNuevoGrupo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlNuevoGrupo_MouseDown);
            this.lblNuevoGrupo.MouseEnter += new System.EventHandler(this.pnlNuevoGrupo_MouseEnter);
            this.lblNuevoGrupo.MouseLeave += new System.EventHandler(this.pnlNuevoGrupo_MouseLeave);
            this.lblNuevoGrupo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlNuevoGrupo_MouseUp);
            // 
            // pbxNuevoGrupo
            // 
            this.pbxNuevoGrupo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pbxNuevoGrupo.Image = ((System.Drawing.Image)(resources.GetObject("pbxNuevoGrupo.Image")));
            this.pbxNuevoGrupo.Location = new System.Drawing.Point(8, 8);
            this.pbxNuevoGrupo.Name = "pbxNuevoGrupo";
            this.pbxNuevoGrupo.Size = new System.Drawing.Size(40, 40);
            this.pbxNuevoGrupo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxNuevoGrupo.TabIndex = 17;
            this.pbxNuevoGrupo.TabStop = false;
            this.pbxNuevoGrupo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlNuevoGrupo_MouseDown);
            this.pbxNuevoGrupo.MouseEnter += new System.EventHandler(this.pnlNuevoGrupo_MouseEnter);
            this.pbxNuevoGrupo.MouseLeave += new System.EventHandler(this.pnlNuevoGrupo_MouseLeave);
            this.pbxNuevoGrupo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlNuevoGrupo_MouseUp);
            // 
            // lblBusqueda2
            // 
            this.lblBusqueda2.BackColor = System.Drawing.Color.Transparent;
            this.lblBusqueda2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblBusqueda2.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBusqueda2.ForeColor = System.Drawing.Color.Silver;
            this.lblBusqueda2.Location = new System.Drawing.Point(11, 11);
            this.lblBusqueda2.Name = "lblBusqueda2";
            this.lblBusqueda2.Size = new System.Drawing.Size(25, 25);
            this.lblBusqueda2.TabIndex = 25;
            this.lblBusqueda2.Text = "";
            // 
            // txtAgregar
            // 
            this.txtAgregar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAgregar.Font = new System.Drawing.Font("Work Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAgregar.Location = new System.Drawing.Point(45, 15);
            this.txtAgregar.Name = "txtAgregar";
            this.txtAgregar.ShortcutsEnabled = false;
            this.txtAgregar.Size = new System.Drawing.Size(187, 19);
            this.txtAgregar.TabIndex = 1;
            this.txtAgregar.TextChanged += new System.EventHandler(this.txtAgregar_TextChanged);
            this.txtAgregar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAgregar_KeyPress);
            // 
            // btnRetorno
            // 
            this.btnRetorno.FlatAppearance.BorderSize = 0;
            this.btnRetorno.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnRetorno.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRetorno.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetorno.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(152)))), ((int)(((byte)(213)))));
            this.btnRetorno.Location = new System.Drawing.Point(235, 4);
            this.btnRetorno.Name = "btnRetorno";
            this.btnRetorno.Size = new System.Drawing.Size(45, 37);
            this.btnRetorno.TabIndex = 0;
            this.btnRetorno.Text = "";
            this.btnRetorno.UseVisualStyleBackColor = true;
            this.btnRetorno.Click += new System.EventHandler(this.btnRetorno_Click);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(280, 520);
            this.shapeContainer1.TabIndex = 21;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.Silver;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.SelectionColor = System.Drawing.Color.Silver;
            this.lineShape1.X1 = 42;
            this.lineShape1.X2 = 231;
            this.lineShape1.Y1 = 36;
            this.lineShape1.Y2 = 36;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            // 
            // mensajes
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(920, 520);
            this.Controls.Add(this.pnlAgregar);
            this.Controls.Add(this.pnlBuscar);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pnlInfo);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.flpConversaciones);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlMensajes);
            this.Font = new System.Drawing.Font("Work Sans", 12F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "mensajes";
            this.Text = "mensajes";
            this.Load += new System.EventHandler(this.mensajes_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flpConversaciones.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.pnlBuscar.ResumeLayout(false);
            this.pnlBuscar.PerformLayout();
            this.pnlAgregar.ResumeLayout(false);
            this.pnlAgregar.PerformLayout();
            this.pnlContinuar.ResumeLayout(false);
            this.pnlIntegrantes.ResumeLayout(false);
            this.pnlIntegrantes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxIntegrantes)).EndInit();
            this.pnlNuevoGrupo.ResumeLayout(false);
            this.pnlNuevoGrupo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxNuevoGrupo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblEnviar;
        private System.Windows.Forms.TextBox txtMensaje;
        private System.Windows.Forms.Label lblIconEmojis;
        private System.Windows.Forms.Label lblIconArchivos;
        private System.Windows.Forms.FlowLayoutPanel flpConversaciones;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel pnlMensajes;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblIconInfo;
        private System.Windows.Forms.Label lblNombreConversacion;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblIconPlus;
        private System.Windows.Forms.Label lblIconSearch;
        private System.Windows.Forms.Panel pnlInfo;
        private System.Windows.Forms.Label labelSecciones;
        private System.Windows.Forms.Label lblNombreInfo;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.Panel pnlBuscar;
        private System.Windows.Forms.Button btnIconRegresar;
        private System.Windows.Forms.FlowLayoutPanel flpBusqueda;
        public System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.Panel pnlAgregar;
        private System.Windows.Forms.FlowLayoutPanel flpAgregar;
        public System.Windows.Forms.TextBox txtAgregar;
        private System.Windows.Forms.Button btnRetorno;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblNameIdentificador;
        private System.Windows.Forms.Label lblBusqueda1;
        private System.Windows.Forms.Label lblBusqueda2;
        private System.Windows.Forms.Panel pnlNuevoGrupo;
        private System.Windows.Forms.Label lblNuevoGrupo;
        private System.Windows.Forms.PictureBox pbxNuevoGrupo;
        private System.Windows.Forms.Panel pnlContinuar;
        private System.Windows.Forms.Label lblContinuar;
        private System.Windows.Forms.Panel pnlIntegrantes;
        private System.Windows.Forms.Label lblIntegrantes;
        private System.Windows.Forms.PictureBox pbxIntegrantes;
    }
}