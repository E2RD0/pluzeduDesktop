﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginForm.Database
{
    class constructor
    {
        //CONSTRUCTOR USUARIO
        public int idUsuario { get; set; }
        public string nombresUsuario { get; set; }
        public string apellidosUsuario { get; set; }
        public string usernameUsuario { get; set; }
        public string emailUsuario { get; set; }
        public string claveUsuario { get; set; }
        public int codigoUsuario { get; set; }
        public int id_usuariotipoUsuario { get; set; }
        public int id_usuarioestadoUsuario { get; set; }

        //CONSTRUCTOR NIVEL
        public int idNivel { get; set; }
        public string nombreNivel { get; set; }
    }
}
