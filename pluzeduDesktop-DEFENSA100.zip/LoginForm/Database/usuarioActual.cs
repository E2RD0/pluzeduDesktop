﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginForm.Database
{
    class usuarioActual
    {
        public static int idUsuario { get; set; }
        public static string nombresUsuario { get; set; }
        public static string apellidosUsuario { get; set; }
        public static string usernameUsuario { get; set; }
        public static string emailUsuario { get; set; }
        public static string claveUsuario { get; set; }
        public static int codigoUsuario { get; set; }
        public static int id_usuariotipoUsuario { get; set; }
        public static int id_usuarioestadoUsuario { get; set; }

    }
}
