﻿namespace LoginForm.Admin
{
    partial class principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlNiveles = new System.Windows.Forms.Panel();
            this.lblIconAward = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlEstudiantes = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblIIconUserGraduate = new System.Windows.Forms.Label();
            this.pnlMaestros = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.lblIconChalkboardTeacher = new System.Windows.Forms.Label();
            this.pnlAdministradores = new System.Windows.Forms.Panel();
            this.lblIconUser = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pnlGraficas = new System.Windows.Forms.Panel();
            this.lblconChart = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlNiveles.SuspendLayout();
            this.pnlEstudiantes.SuspendLayout();
            this.pnlMaestros.SuspendLayout();
            this.pnlAdministradores.SuspendLayout();
            this.pnlGraficas.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlNiveles
            // 
            this.pnlNiveles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(173)))), ((int)(((byte)(221)))));
            this.pnlNiveles.Controls.Add(this.lblIconAward);
            this.pnlNiveles.Controls.Add(this.label1);
            this.pnlNiveles.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlNiveles.ForeColor = System.Drawing.Color.White;
            this.pnlNiveles.Location = new System.Drawing.Point(100, 24);
            this.pnlNiveles.Name = "pnlNiveles";
            this.pnlNiveles.Size = new System.Drawing.Size(200, 200);
            this.pnlNiveles.TabIndex = 0;
            this.pnlNiveles.Click += new System.EventHandler(this.pnlNiveles_Click);
            this.pnlNiveles.MouseEnter += new System.EventHandler(this.label1_MouseEnter);
            this.pnlNiveles.MouseLeave += new System.EventHandler(this.label1_MouseLeave);
            // 
            // lblIconAward
            // 
            this.lblIconAward.AutoSize = true;
            this.lblIconAward.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIconAward.Location = new System.Drawing.Point(55, 45);
            this.lblIconAward.Name = "lblIconAward";
            this.lblIconAward.Size = new System.Drawing.Size(95, 83);
            this.lblIconAward.TabIndex = 1;
            this.lblIconAward.Text = "";
            this.lblIconAward.Click += new System.EventHandler(this.pnlNiveles_Click);
            this.lblIconAward.MouseEnter += new System.EventHandler(this.label1_MouseEnter);
            this.lblIconAward.MouseLeave += new System.EventHandler(this.label1_MouseLeave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 160);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Niveles";
            this.label1.Click += new System.EventHandler(this.pnlNiveles_Click);
            this.label1.MouseEnter += new System.EventHandler(this.label1_MouseEnter);
            this.label1.MouseLeave += new System.EventHandler(this.label1_MouseLeave);
            // 
            // pnlEstudiantes
            // 
            this.pnlEstudiantes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(173)))), ((int)(((byte)(221)))));
            this.pnlEstudiantes.Controls.Add(this.label4);
            this.pnlEstudiantes.Controls.Add(this.lblIIconUserGraduate);
            this.pnlEstudiantes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlEstudiantes.ForeColor = System.Drawing.Color.White;
            this.pnlEstudiantes.Location = new System.Drawing.Point(365, 24);
            this.pnlEstudiantes.Name = "pnlEstudiantes";
            this.pnlEstudiantes.Size = new System.Drawing.Size(200, 200);
            this.pnlEstudiantes.TabIndex = 1;
            this.pnlEstudiantes.Click += new System.EventHandler(this.pnlEstudiantes_Click);
            this.pnlEstudiantes.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlEstudiantes_Paint);
            this.pnlEstudiantes.MouseEnter += new System.EventHandler(this.label3_MouseEnter);
            this.pnlEstudiantes.MouseLeave += new System.EventHandler(this.label3_MouseLeave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(49, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Estudiantes";
            this.label4.Click += new System.EventHandler(this.pnlEstudiantes_Click);
            this.label4.MouseEnter += new System.EventHandler(this.label3_MouseEnter);
            this.label4.MouseLeave += new System.EventHandler(this.label3_MouseLeave);
            // 
            // lblIIconUserGraduate
            // 
            this.lblIIconUserGraduate.AutoSize = true;
            this.lblIIconUserGraduate.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIIconUserGraduate.Location = new System.Drawing.Point(50, 45);
            this.lblIIconUserGraduate.Name = "lblIIconUserGraduate";
            this.lblIIconUserGraduate.Size = new System.Drawing.Size(105, 83);
            this.lblIIconUserGraduate.TabIndex = 3;
            this.lblIIconUserGraduate.Text = "";
            this.lblIIconUserGraduate.Click += new System.EventHandler(this.pnlEstudiantes_Click);
            this.lblIIconUserGraduate.MouseEnter += new System.EventHandler(this.label3_MouseEnter);
            this.lblIIconUserGraduate.MouseLeave += new System.EventHandler(this.label3_MouseLeave);
            // 
            // pnlMaestros
            // 
            this.pnlMaestros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(173)))), ((int)(((byte)(221)))));
            this.pnlMaestros.Controls.Add(this.label6);
            this.pnlMaestros.Controls.Add(this.lblIconChalkboardTeacher);
            this.pnlMaestros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlMaestros.ForeColor = System.Drawing.Color.White;
            this.pnlMaestros.Location = new System.Drawing.Point(630, 24);
            this.pnlMaestros.Name = "pnlMaestros";
            this.pnlMaestros.Size = new System.Drawing.Size(200, 200);
            this.pnlMaestros.TabIndex = 2;
            this.pnlMaestros.Click += new System.EventHandler(this.pnlMaestros_Click);
            this.pnlMaestros.MouseEnter += new System.EventHandler(this.pnlMaestros_MouseEnter);
            this.pnlMaestros.MouseLeave += new System.EventHandler(this.label5_MouseLeave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(61, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Maestros";
            this.label6.Click += new System.EventHandler(this.pnlMaestros_Click);
            this.label6.MouseEnter += new System.EventHandler(this.pnlMaestros_MouseEnter);
            this.label6.MouseLeave += new System.EventHandler(this.label5_MouseLeave);
            // 
            // lblIconChalkboardTeacher
            // 
            this.lblIconChalkboardTeacher.AutoSize = true;
            this.lblIconChalkboardTeacher.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIconChalkboardTeacher.Location = new System.Drawing.Point(35, 45);
            this.lblIconChalkboardTeacher.Name = "lblIconChalkboardTeacher";
            this.lblIconChalkboardTeacher.Size = new System.Drawing.Size(135, 83);
            this.lblIconChalkboardTeacher.TabIndex = 5;
            this.lblIconChalkboardTeacher.Text = "";
            this.lblIconChalkboardTeacher.Click += new System.EventHandler(this.pnlMaestros_Click);
            this.lblIconChalkboardTeacher.MouseEnter += new System.EventHandler(this.pnlMaestros_MouseEnter);
            this.lblIconChalkboardTeacher.MouseLeave += new System.EventHandler(this.label5_MouseLeave);
            // 
            // pnlAdministradores
            // 
            this.pnlAdministradores.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(173)))), ((int)(((byte)(221)))));
            this.pnlAdministradores.Controls.Add(this.lblIconUser);
            this.pnlAdministradores.Controls.Add(this.label8);
            this.pnlAdministradores.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlAdministradores.ForeColor = System.Drawing.Color.White;
            this.pnlAdministradores.Location = new System.Drawing.Point(100, 275);
            this.pnlAdministradores.Name = "pnlAdministradores";
            this.pnlAdministradores.Size = new System.Drawing.Size(200, 200);
            this.pnlAdministradores.TabIndex = 1;
            this.pnlAdministradores.Click += new System.EventHandler(this.pnlAdministradores_Click);
            this.pnlAdministradores.MouseEnter += new System.EventHandler(this.pnlAdministradores_MouseEnter);
            this.pnlAdministradores.MouseLeave += new System.EventHandler(this.label8_MouseLeave);
            // 
            // lblIconUser
            // 
            this.lblIconUser.AutoSize = true;
            this.lblIconUser.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIconUser.Location = new System.Drawing.Point(50, 45);
            this.lblIconUser.Name = "lblIconUser";
            this.lblIconUser.Size = new System.Drawing.Size(105, 83);
            this.lblIconUser.TabIndex = 7;
            this.lblIconUser.Text = "";
            this.lblIconUser.Click += new System.EventHandler(this.pnlAdministradores_Click);
            this.lblIconUser.MouseEnter += new System.EventHandler(this.pnlAdministradores_MouseEnter);
            this.lblIconUser.MouseLeave += new System.EventHandler(this.label8_MouseLeave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "Administradores";
            this.label8.Click += new System.EventHandler(this.pnlAdministradores_Click);
            this.label8.MouseEnter += new System.EventHandler(this.pnlAdministradores_MouseEnter);
            this.label8.MouseLeave += new System.EventHandler(this.label8_MouseLeave);
            // 
            // pnlGraficas
            // 
            this.pnlGraficas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(173)))), ((int)(((byte)(221)))));
            this.pnlGraficas.Controls.Add(this.lblconChart);
            this.pnlGraficas.Controls.Add(this.label3);
            this.pnlGraficas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlGraficas.ForeColor = System.Drawing.Color.White;
            this.pnlGraficas.Location = new System.Drawing.Point(365, 275);
            this.pnlGraficas.Name = "pnlGraficas";
            this.pnlGraficas.Size = new System.Drawing.Size(200, 200);
            this.pnlGraficas.TabIndex = 8;
            this.pnlGraficas.Click += new System.EventHandler(this.pnlGraficas_Click);
            // 
            // lblconChart
            // 
            this.lblconChart.AutoSize = true;
            this.lblconChart.Font = new System.Drawing.Font("Font Awesome 5 Free Solid", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblconChart.Location = new System.Drawing.Point(50, 45);
            this.lblconChart.Name = "lblconChart";
            this.lblconChart.Size = new System.Drawing.Size(115, 83);
            this.lblconChart.TabIndex = 7;
            this.lblconChart.Text = "";
            this.lblconChart.Click += new System.EventHandler(this.lblconChart_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(63, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Gráficas";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.lblconChart_Click);
            // 
            // principal
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(920, 520);
            this.Controls.Add(this.pnlGraficas);
            this.Controls.Add(this.pnlAdministradores);
            this.Controls.Add(this.pnlMaestros);
            this.Controls.Add(this.pnlEstudiantes);
            this.Controls.Add(this.pnlNiveles);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "principal";
            this.Text = "principal";
            this.Load += new System.EventHandler(this.principal_Load);
            this.pnlNiveles.ResumeLayout(false);
            this.pnlNiveles.PerformLayout();
            this.pnlEstudiantes.ResumeLayout(false);
            this.pnlEstudiantes.PerformLayout();
            this.pnlMaestros.ResumeLayout(false);
            this.pnlMaestros.PerformLayout();
            this.pnlAdministradores.ResumeLayout(false);
            this.pnlAdministradores.PerformLayout();
            this.pnlGraficas.ResumeLayout(false);
            this.pnlGraficas.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlNiveles;
        private System.Windows.Forms.Label lblIconAward;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlEstudiantes;
        private System.Windows.Forms.Label lblIIconUserGraduate;
        private System.Windows.Forms.Panel pnlMaestros;
        private System.Windows.Forms.Panel pnlAdministradores;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblIconChalkboardTeacher;
        private System.Windows.Forms.Label lblIconUser;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pnlGraficas;
        private System.Windows.Forms.Label lblconChart;
        private System.Windows.Forms.Label label3;
    }
}