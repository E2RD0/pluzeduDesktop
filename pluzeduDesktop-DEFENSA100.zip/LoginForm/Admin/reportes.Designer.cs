﻿namespace LoginForm.Admin
{
    partial class reportes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGenerar1 = new System.Windows.Forms.Button();
            this.btnGenerar3 = new System.Windows.Forms.Button();
            this.btnGenerar2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGenerar1
            // 
            this.btnGenerar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(152)))), ((int)(((byte)(213)))));
            this.btnGenerar1.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnGenerar1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnGenerar1.FlatAppearance.BorderSize = 0;
            this.btnGenerar1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.btnGenerar1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerar1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerar1.ForeColor = System.Drawing.Color.White;
            this.btnGenerar1.Location = new System.Drawing.Point(71, 123);
            this.btnGenerar1.Name = "btnGenerar1";
            this.btnGenerar1.Size = new System.Drawing.Size(258, 55);
            this.btnGenerar1.TabIndex = 35;
            this.btnGenerar1.Text = "Generar reporte de usuarios ";
            this.btnGenerar1.UseVisualStyleBackColor = false;
            // 
            // btnGenerar3
            // 
            this.btnGenerar3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(152)))), ((int)(((byte)(213)))));
            this.btnGenerar3.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnGenerar3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnGenerar3.FlatAppearance.BorderSize = 0;
            this.btnGenerar3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.btnGenerar3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerar3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerar3.ForeColor = System.Drawing.Color.White;
            this.btnGenerar3.Location = new System.Drawing.Point(71, 293);
            this.btnGenerar3.Name = "btnGenerar3";
            this.btnGenerar3.Size = new System.Drawing.Size(258, 55);
            this.btnGenerar3.TabIndex = 36;
            this.btnGenerar3.Text = "Generar reporte de usuarios ";
            this.btnGenerar3.UseVisualStyleBackColor = false;
            // 
            // btnGenerar2
            // 
            this.btnGenerar2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(152)))), ((int)(((byte)(213)))));
            this.btnGenerar2.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnGenerar2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnGenerar2.FlatAppearance.BorderSize = 0;
            this.btnGenerar2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.btnGenerar2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerar2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerar2.ForeColor = System.Drawing.Color.White;
            this.btnGenerar2.Location = new System.Drawing.Point(71, 209);
            this.btnGenerar2.Name = "btnGenerar2";
            this.btnGenerar2.Size = new System.Drawing.Size(258, 55);
            this.btnGenerar2.TabIndex = 37;
            this.btnGenerar2.Text = "Generar reporte de usuarios ";
            this.btnGenerar2.UseVisualStyleBackColor = false;
            // 
            // reportes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 520);
            this.Controls.Add(this.btnGenerar2);
            this.Controls.Add(this.btnGenerar3);
            this.Controls.Add(this.btnGenerar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "reportes";
            this.Text = "reportes";
            this.Load += new System.EventHandler(this.reportes_Load);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Button btnGenerar1;
        public System.Windows.Forms.Button btnGenerar3;
        public System.Windows.Forms.Button btnGenerar2;
    }
}